## Test environments

* local OS X install, R 3.4.0
* local Ubuntu 16.04, R 3.4.3
* Ubuntu 14.04.5 (on travis-ci), oldrel, release, devel
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 notes

* checking CRAN incoming feasibility ... NOTE

Possibly mis-spelled words in DESCRIPTION:
  Whately (15:16, 17:41)

Whately is not mis-spelled.
  
## Reverse dependencies

There are no reverse dependencies.

