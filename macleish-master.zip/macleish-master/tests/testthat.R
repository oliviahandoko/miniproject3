library(testthat)
library(macleish)

test_check("macleish")
